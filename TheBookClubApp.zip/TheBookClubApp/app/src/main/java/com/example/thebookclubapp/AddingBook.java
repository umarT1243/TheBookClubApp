package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddingBook extends AppCompatActivity {

    TextView textview4;
    EditText title_input, author_input, publisher_input, isbn10_input;
    Button add_button, back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_book);

        title_input = findViewById(R.id.title_input);
        author_input = findViewById(R.id.author_input);
        publisher_input = findViewById(R.id.publisher_input);
        isbn10_input = findViewById(R.id.isbn10_input);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BooksDBHelper myDB = new BooksDBHelper(AddingBook.this);
                myDB.addBook(title_input.getText().toString().trim(),
                        author_input.getText().toString().trim(),
                        publisher_input.getText().toString().trim(),
                        Integer.valueOf(isbn10_input.getText().toString().trim()));

            }

        });



    }



    public void onlibrary (View view) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }

    public void onReview(View view) {
        Intent intent = new Intent(this, WriteReview.class);
        startActivity(intent);

    }
}