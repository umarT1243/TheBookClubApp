package com.example.thebookclubapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewReviewActivity extends AppCompatActivity {

    TextView title_input, name_input, review_input, rating_input;
    Button delete_button;

    String id, title, name, review, rating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_review);

        title_input = findViewById(R.id.title_input2);
        name_input = findViewById(R.id.name_input2);
        review_input = findViewById(R.id.review_input2);
        rating_input = findViewById(R.id.rating_input2);
        delete_button = findViewById(R.id.delete_button);

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();

            }
        });


        getAndSetIntentData();

    }


    void getAndSetIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("title") &&
                getIntent().hasExtra("name") &&
                getIntent().hasExtra("review") && getIntent().hasExtra("rating")){
            //Getting Data from Intent
            id = getIntent().getStringExtra("id");
            title = getIntent().getStringExtra("title");
            name = getIntent().getStringExtra("name");
            review = getIntent().getStringExtra("review");
            rating = getIntent().getStringExtra("rating");

            //Setting Intent Data
            title_input.setText(title);
            name_input.setText(name);
            review_input.setText(review);
            rating_input.setText(rating);
            Log.d("stev", title+" "+name+" "+review+""+rating);
        }else{
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + title + " ?");
        builder.setMessage("Are you sure you want to delete " + title + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ReviewsDBHelper myDB = new ReviewsDBHelper(ViewReviewActivity.this);
                myDB.deleteOneRow(id);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    public void onLibrary(View view) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }


    public void onReview(View view) {
        Intent intent = new Intent(this, ReviewPage.class);
        startActivity(intent);
    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }
}