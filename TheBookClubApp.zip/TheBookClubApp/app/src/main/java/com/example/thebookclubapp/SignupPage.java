package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignupPage extends AppCompatActivity {
    private Button signupButton;
    private EditText editTextFullName, editTextEmail, editTextPassword, editTextAge;
    DBHelper helper = new DBHelper(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);

        signupButton = (Button) findViewById(R.id.signupButton);
        editTextFullName = (EditText) findViewById(R.id.fullName);
        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.password);
        editTextAge = (EditText) findViewById(R.id.age);

    }

    public void onSignUp(View view) {
        SignUpUser();
    }
    public void onSignIn(View view) {
        startActivity(new Intent(this, MainActivity.class));

    }

    private void SignUpUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String fullName = editTextFullName.getText().toString().trim();
        String ageString = editTextAge.getText().toString().trim(); // Get age as string;

        if (fullName.isEmpty()) {
            editTextFullName.setError("Full name is required");
            editTextFullName.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please provide valid email!");
            editTextEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Min password length should be 6 characters!");
            editTextPassword.requestFocus();
            return;
        }

        if (ageString.isEmpty()) { // Check if age is empty
            editTextAge.setError("Age is required");
            editTextAge.requestFocus();
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageString); // Parse age to integer
        } catch (NumberFormatException e) {
            editTextAge.setError("Invalid age format");
            editTextAge.requestFocus();
            return;
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setAge(age);
        user.setPassword(password);

        Log.d("user.getFullName", user.getFullName());
        Log.d("user.getEmail", user.getEmail());
        Log.d("user.getAge", String.valueOf(user.getAge()));
        Log.d("user.getPassword", user.getPassword());

        if (helper.insertData(user)) {
            String userFullName = helper.getUserName(email);
            Log.d("Successful Signup", userFullName);
            Intent i = new Intent(SignupPage.this, Homepage.class);
            i.putExtra("username", userFullName);
            startActivity(i);
        } else {
            Toast.makeText(this, "Sign up could not be completed, please try again",
                    Toast.LENGTH_LONG).show();
        }
    }

    public void loginPageActivity(View view) {
        Intent intent = new Intent(this, LoginPage.class);
        startActivity(intent);
    }
}