package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class WriteReview extends AppCompatActivity {


    EditText title_input, name_input, review_input, rating_input;
    Button submit_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_review);

        title_input = findViewById(R.id.title_input);
        name_input = findViewById(R.id.name_input);
        review_input = findViewById(R.id.review_input);
        rating_input = findViewById(R.id.rating_input);
        submit_button = findViewById(R.id.submit_button);
        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReviewsDBHelper myDB = new ReviewsDBHelper(WriteReview.this);
                myDB.addReview(title_input.getText().toString().trim(),
                        name_input.getText().toString().trim(),
                        review_input.getText().toString().trim(),
                        Integer.valueOf(rating_input.getText().toString().trim()));

            }

        });


    }

    public void ondeliver(View view) {
        Intent intent = new Intent(this, ReviewPage.class);
        startActivity(intent);
    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }
}