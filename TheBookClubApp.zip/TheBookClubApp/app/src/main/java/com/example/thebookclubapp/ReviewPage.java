package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ReviewPage extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton add_button;

    ReviewsDBHelper mydb;
    ArrayList<String> review_id, review_title, review_name, review_review, review_rating;

    ReviewsAdapter reviewsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_page);

        recyclerView = findViewById(R.id.recyclerView2);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ReviewPage.this, WriteReview.class);
                startActivity(intent);
            }
        });

        mydb = new ReviewsDBHelper(ReviewPage.this);
        review_id = new ArrayList<>();
        review_title = new ArrayList<>();
        review_name = new ArrayList<>();
        review_review = new ArrayList<>();
        review_rating = new ArrayList<>();

        storeDataINArrays();
        reviewsAdapter = new ReviewsAdapter(ReviewPage.this, review_id, review_title, review_name, review_review, review_rating);
        recyclerView.setAdapter(reviewsAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ReviewPage.this));
    }

    void storeDataINArrays(){
        Cursor cursor = mydb.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "no data", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                review_id.add(cursor.getString(0));
                review_title.add(cursor.getString(1));
                review_name.add(cursor.getString(2));
                review_review.add(cursor.getString(3));
                review_rating.add(cursor.getString(4));

            }

        }



    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }
}
