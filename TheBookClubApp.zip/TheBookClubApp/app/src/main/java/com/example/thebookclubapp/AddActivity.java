package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class AddActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton add_button;

    BooksDBHelper mydb;
    ArrayList<String> book_id, book_title, book_author, book_publisher, book_isbn10;

    CustomAdapter customAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddActivity.this, AddingBook.class);
                startActivity(intent);
            }
        });

        mydb = new BooksDBHelper(AddActivity.this);
        book_id = new ArrayList<>();
        book_title = new ArrayList<>();
        book_author = new ArrayList<>();
        book_publisher = new ArrayList<>();
        book_isbn10 = new ArrayList<>();

        storeDataINArrays();
        customAdapter = new CustomAdapter(AddActivity.this, book_id, book_title, book_author, book_publisher, book_isbn10);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(AddActivity.this));
    }

    void storeDataINArrays(){
        Cursor cursor = mydb.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "no data", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                book_id.add(cursor.getString(0));
                book_title.add(cursor.getString(1));
                book_author.add(cursor.getString(2));
                book_publisher.add(cursor.getString(3));
                book_isbn10.add(cursor.getString(4));

            }

        }



    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }
}
