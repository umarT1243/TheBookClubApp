package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class search extends AppCompatActivity {

    RecyclerView recyclerView3;

    BooksDBHelper mydb;
    ArrayList<String> book_id, book_title, book_author, book_publisher, book_isbn10;

    CustomAdapter customAdapter;
    SearchView searchView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        recyclerView3 = findViewById(R.id.recyclerView3);
        searchView = findViewById(R.id.searchView);


        mydb = new BooksDBHelper(search.this);
        book_id = new ArrayList<>();
        book_title = new ArrayList<>();
        book_author = new ArrayList<>();
        book_publisher = new ArrayList<>();
        book_isbn10 = new ArrayList<>();

        storeDataINArrays();
        customAdapter = new CustomAdapter(search.this, book_id, book_title, book_author, book_publisher, book_isbn10);
        recyclerView3.setAdapter(customAdapter);
        recyclerView3.setLayoutManager(new LinearLayoutManager(search.this));
    }

    void storeDataINArrays(){
        Cursor cursor = mydb.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "no data", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                book_id.add(cursor.getString(0));
                book_title.add(cursor.getString(1));
                book_author.add(cursor.getString(2));
                book_publisher.add(cursor.getString(3));
                book_isbn10.add(cursor.getString(4));

            }

        }



    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }
}