package com.example.thebookclubapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText fullNameEditText, ageEditText, emailEditText, passwordEditText;
    private Button updateButton;
    private DBHelper dbHelper;
    private String currentUserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    public void onUpdate(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }


}

