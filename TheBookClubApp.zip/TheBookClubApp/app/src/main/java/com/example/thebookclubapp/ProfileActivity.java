package com.example.thebookclubapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText editTextFullName, editTextEmail, editTextAge, editTextPassword;
    private Button updateButton;
    private DBHelper dbHelper;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        dbHelper = new DBHelper(this);

        // Bind your view components
        editTextFullName = findViewById(R.id.editTextFullName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextAge = findViewById(R.id.editTextAge);
        editTextPassword = findViewById(R.id.editTextPassword);
        updateButton = findViewById(R.id.updateButton);


        loadUserDetails();

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserChanges();
            }
        });
    }

    private void loadUserDetails() {

        userEmail = "tester@test.com";

        User user = dbHelper.getUserDetails(userEmail);

        if (user != null) {
            editTextFullName.setText(user.getFullName());
            editTextEmail.setText(user.getEmail());
            editTextAge.setText(String.valueOf(user.getAge()));
            editTextPassword.setText(user.getPassword());
            Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUserChanges() {
        String fullName = editTextFullName.getText().toString();
        int age = Integer.parseInt(editTextAge.getText().toString());
        String password = editTextPassword.getText().toString();
        boolean isUpdated = dbHelper.updateUserDetails(userEmail, fullName, age, password);

        if (isUpdated) {
            Toast.makeText(ProfileActivity.this, "Details Updated Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ProfileActivity.this, "Failed to update details", Toast.LENGTH_SHORT).show();
        }
    }

    public void onHome(View view) {
        startActivity(new Intent(this, Homepage.class));
    }
}


