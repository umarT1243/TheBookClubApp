package com.example.thebookclubapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewBookActivity extends AppCompatActivity {

    TextView title_input, author_input, publisher_input, isbn10_input;
    Button delete_button;

    String id, title, author, publisher, isbn10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_book);

        title_input = findViewById(R.id.title_input2);
        author_input = findViewById(R.id.author_input2);
        publisher_input = findViewById(R.id.publisher_input2);
        isbn10_input = findViewById(R.id.isbn10_input2);
        delete_button = findViewById(R.id.delete_button);

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();

            }
        });







        getAndSetIntentData();

    }


    void getAndSetIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("title") &&
                getIntent().hasExtra("author") &&
                getIntent().hasExtra("publisher") && getIntent().hasExtra("isbn10")){
            //Getting Data from Intent
            id = getIntent().getStringExtra("id");
            title = getIntent().getStringExtra("title");
            author = getIntent().getStringExtra("author");
            publisher = getIntent().getStringExtra("publisher");
            isbn10 = getIntent().getStringExtra("isbn10");

            //Setting Intent Data
            title_input.setText(title);
            author_input.setText(author);
            publisher_input.setText(publisher);
            isbn10_input.setText(isbn10);
            Log.d("stev", title+" "+author+" "+publisher+""+isbn10);
        }else{
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + title + " ?");
        builder.setMessage("Are you sure you want to delete " + title + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                BooksDBHelper myDB = new BooksDBHelper(ViewBookActivity.this);
                myDB.deleteOneRow(id);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    public void onLibrary(View view) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    public void onReview(View view) {
        Intent intent = new Intent(this, WriteReview.class);
        startActivity(intent);
    }

    public void onHome(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
    }


}