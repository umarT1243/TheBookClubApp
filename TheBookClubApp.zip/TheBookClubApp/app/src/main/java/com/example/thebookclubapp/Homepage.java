package com.example.thebookclubapp;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Homepage extends AppCompatActivity {

    FrameLayout container;
    Button mybutton;


    BottomNavigationView bottomNavigationView;

    HomeFragment homeFragment = new HomeFragment();
    NotifsFragment notifsFragment = new NotifsFragment();
    EventsFragment eventsFragment = new EventsFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);




        bottomNavigationView  = findViewById(R.id.bottom_nav);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();
                        return true;
                    case R.id.notifs:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,notifsFragment).commit();
                        return true;
                    case R.id.events:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,eventsFragment).commit();
                        return true;
                }

                return false;
            }


        });




    }


    public void onSignOut(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }

    public void onHome(View view) {
        startActivity(new Intent(this, Homepage.class));
    }

    public void onProfile(View view) {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    public void onLibrary(View view) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    public void onAdd(View view) {
        Intent intent = new Intent(this, AddingBook.class);
        startActivity(intent);
    }

    public void onReview(View view) {
        Intent intent = new Intent(this, ReviewPage.class);
        startActivity(intent);
    }

    public void onSearch(View view) {
        Intent intent = new Intent(this, search.class);
        startActivity(intent);
    }



}


