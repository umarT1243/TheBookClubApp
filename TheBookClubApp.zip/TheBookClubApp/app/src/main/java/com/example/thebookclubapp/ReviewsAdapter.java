package com.example.thebookclubapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReviewsAdapter extends RecyclerView.Adapter<ReviewsAdapter.MyViewHolder> {

    private Context context;
    private ArrayList review_id, review_title, review_name, review_review, review_rating;
    private int position;

    ReviewsAdapter(Context context,
                  ArrayList review_id,
                  ArrayList review_title,
                  ArrayList review_name,
                  ArrayList review_review,
                  ArrayList review_rating) {

        this.context = context;
        this.review_id = review_id;
        this.review_title = review_title;
        this.review_name= review_name;
        this.review_review = review_review;
        this.review_rating = review_rating;


    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.review_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull  MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        this.position = position;

        holder.review_id.setText(String.valueOf(review_id.get(position)));
        holder.review_title.setText(String.valueOf(review_title.get(position)));
        holder.review_name.setText(String.valueOf(review_name.get(position)));
        holder.review_review.setText(String.valueOf(review_review.get(position)));
        holder.review_rating.setText(String.valueOf(review_rating.get(position)));
        holder.mainLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ViewReviewActivity.class);
                intent.putExtra("id", String.valueOf(review_id.get(position)));
                intent.putExtra("title", String.valueOf(review_title.get(position)));
                intent.putExtra("name", String.valueOf(review_name.get(position)));
                intent.putExtra("review", String.valueOf(review_review.get(position)));
                intent.putExtra("rating", String.valueOf(review_rating.get(position)));
                context.startActivity(intent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return review_id.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView review_id, review_title, review_name, review_review, review_rating;
        LinearLayout mainLayout2;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            review_id = itemView.findViewById(R.id.review_id);
            review_title = itemView.findViewById(R.id.review_title);
            review_name = itemView.findViewById(R.id.review_name);
            review_review = itemView.findViewById(R.id.review_review);
            review_rating = itemView.findViewById(R.id.review_rating);
            mainLayout2 = itemView.findViewById(R.id.mainLayout2);

        }
    }
}

